package com.example.demo;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.example.demo.domain.Calender;

public class DemoApplication {
	
	private static final String ACCESS_TOKEN = "eyJ0eXAiOiJKV1QiLCJub25jZSI6IkFRQUJBQUFBQUFEQ29NcGpKWHJ4VHE5Vkc5dGUtN0ZYbEVmRlgwSzdrWG5lU3M4N0pIc2U5dlNyanJtaTdsQzVXUzhrY0VOWkdRdXJSNHAtYkR5ZmVHS1pfcThObjJPWkUxSG5ieEZweGw4M3pJT05xR0FMZWlBQSIsImFsZyI6IlJTMjU2IiwieDV0IjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIiwia2lkIjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIn0.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hNjI4ZGE1OC1iMDk5LTQ2M2UtYjliZC00OTg3Y2Q0NWVkNzUvIiwiaWF0IjoxNTU4NTE3MDczLCJuYmYiOjE1NTg1MTcwNzMsImV4cCI6MTU1ODUyMDk3MywiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFWUUFxLzhMQUFBQWJIN01aQk5HOWVGUFFJM2tDaXFzcmd6K1RCWDh4aWMvTlEwK3JiT1M2QmV1R3pvUzBjK29mNmloNUJ5LzVqV1NwNWJ6L3NhM0JzbEE0blo4MzV2ekpLbXRLTEVNd3dRMnBTWXhsWFhnTU0wPSIsImFtciI6WyJwd2QiLCJtZmEiXSwiYXBwX2Rpc3BsYXluYW1lIjoiRW1wbG95ZWVBcHBsaWNhdGlvbiIsImFwcGlkIjoiNTYzMDRiNWEtNDdjMC00ZGIwLWJmNDMtZjAzZGUxNzYwOTg5IiwiYXBwaWRhY3IiOiIxIiwiZmFtaWx5X25hbWUiOiJQdXJuYXNpcmkiLCJnaXZlbl9uYW1lIjoiTWFsaW5nYSIsImlwYWRkciI6IjIwMi42OS4yMDAuODIiLCJuYW1lIjoiTWFsaW5nYSBQdXJuYXNpcmkiLCJvaWQiOiJiZDQ5OGI2NC02OWY4LTQwODMtODVmYi0zMGE1MTllZThhOGMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTUyNzcyMzI1Mi0xNDYzMjIyMzY2LTE5MjI0NTAyMzMtMTMzMTQzIiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAwNDFBNzBCMDMiLCJzY3AiOiJDYWxlbmRhcnMuUmVhZCBDYWxlbmRhcnMuUmVhZFdyaXRlIENvbnRhY3RzLlJlYWQgTWFpbC5SZWFkIG9wZW5pZCBwcm9maWxlIFVzZXIuUmVhZCBlbWFpbCIsInNpZ25pbl9zdGF0ZSI6WyJrbXNpIl0sInN1YiI6Im5YUnNzSlVXZEljTmlQTlN3Mnd4LU1LUGpWTEtEUnhDMmIxbkpfSU1zS3MiLCJ0aWQiOiJhNjI4ZGE1OC1iMDk5LTQ2M2UtYjliZC00OTg3Y2Q0NWVkNzUiLCJ1bmlxdWVfbmFtZSI6Im1hbGluZ2EucHVybmFzaXJpQGF4aWF0YWRpZ2l0YWxsYWJzLmNvbSIsInVwbiI6Im1hbGluZ2EucHVybmFzaXJpQGF4aWF0YWRpZ2l0YWxsYWJzLmNvbSIsInV0aSI6InJlTjNoTkFjemthZkhmaHE3SE1uQUEiLCJ2ZXIiOiIxLjAiLCJ4bXNfc3QiOnsic3ViIjoiNUIyRGc0aDdHSmF3b2VRaTFzQ0UwZ1gxQkdhTlV4R245a1JRZHdXbks0ayJ9LCJ4bXNfdGNkdCI6MTQ1ODgxMjY3M30.y2ltnoCRWlsNaUNjkyFN3yj06yQDEN00qq4USeeh5HdhNqeGPUoZHV7bphAjGoCmq0mrkBZSBJepAHZnMyR7mCl8-c372Kmpfb-XXhcneKAhESLn8moT5PCxXx7duM2dr7oLrettfk1gW4OnOfxAf6s6Uy4NJUY81nIYvQvqQH6rGUbdXug3Umbt5DqMi-RfjzGanM56g11idqEPdPkJnGdvY5qdsupU5RI9XEFVGKVYUHkkEqjFb-D9ROnSXK2Sl-QDMLZJ-yVfl487Di9YaTxFqa1lybnBmzx-QtFcw4Nb5VlyE50Vvr7fz0HRyHDIP8EkxGI4YOGycCDtYjVmIg";
	private static final String USER_ID = "bd498b64-69f8-4083-85fb-30a519ee8a8c";
	
	public static void main(String[] args) {
		// getCelenders();
		//getEvents();
		//getRooms();
		//getUsers();
		//createCalender();
		//getContacts();
		 //getUserProfile();
		 getUsers();
	}
	
	static void getCelenders() {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization",ACCESS_TOKEN);
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<String>(headers);	    
	    String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/me/calendars", HttpMethod.GET, entity, String.class)
	    .getBody();	
	    
	    System.out.println("###################################Celenders##########################");
	    
	    System.out.println(body);	
	}
	
	
	static void getUserProfile() {
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization",ACCESS_TOKEN);
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<String>(headers);	    
	    String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/users/a8176408-21c0-4176-9fc4-bf025356ef7c", HttpMethod.GET, entity, String.class)
	    .getBody();	
	    
	    System.out.println("###################################Profile##########################");
	    
	    System.out.println(body);	
		
	}
	
	static void getUsers() {
		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization",ACCESS_TOKEN);
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<String>(headers);	    
	    String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/users", HttpMethod.GET, entity, String.class)
	    .getBody();	
	    
	    System.out.println("###################################Profile##########################");
	    
	    System.out.println(body);	
		
	}
	
	
	
	static void getEvents() {		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + "eyJ0eXAiOiJKV1QiLCJub25jZSI6IkFRQUJBQUFBQUFEQ29NcGpKWHJ4VHE5Vkc5dGUtN0ZYUlIzUU1MaFBYc0hyd2ZIcDA4aWdVem54VEFmSkJYd2R5akp5VHU5MlktczZjLWdMT3l5UnNDRk1CcEdoOGUzRGx2VDBCRWZKQnFOTzRXM19IbkNEOGlBQSIsImFsZyI6IlJTMjU2IiwieDV0IjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIiwia2lkIjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIn0.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hNjI4ZGE1OC1iMDk5LTQ2M2UtYjliZC00OTg3Y2Q0NWVkNzUvIiwiaWF0IjoxNTU4NTAwMTYyLCJuYmYiOjE1NTg1MDAxNjIsImV4cCI6MTU1ODUwNDA2MiwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFWUUFxLzhMQUFBQWFzVzZKa3FFbW05TkVoNktTYTNmMXhBYjdqWXZtVEF6dVNYTktTeTVLditkcnAxcURRdDNseEVtRmVXYmQvd2RXN0hVTVhLTUlFOHB2VWorSitqSkRzaXJLUkVuNkRYMmVJVWJ0OUsrcU44PSIsImFtciI6WyJwd2QiLCJtZmEiXSwiYXBwX2Rpc3BsYXluYW1lIjoiRW1wbG95ZWVBcHBsaWNhdGlvbiIsImFwcGlkIjoiNTYzMDRiNWEtNDdjMC00ZGIwLWJmNDMtZjAzZGUxNzYwOTg5IiwiYXBwaWRhY3IiOiIxIiwiZmFtaWx5X25hbWUiOiJQdXJuYXNpcmkiLCJnaXZlbl9uYW1lIjoiTWFsaW5nYSIsImlwYWRkciI6IjIwMi42OS4yMDAuODIiLCJuYW1lIjoiTWFsaW5nYSBQdXJuYXNpcmkiLCJvaWQiOiJiZDQ5OGI2NC02OWY4LTQwODMtODVmYi0zMGE1MTllZThhOGMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTUyNzcyMzI1Mi0xNDYzMjIyMzY2LTE5MjI0NTAyMzMtMTMzMTQzIiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAwNDFBNzBCMDMiLCJzY3AiOiJDYWxlbmRhcnMuUmVhZFdyaXRlIG9wZW5pZCBwcm9maWxlIGVtYWlsIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoiblhSc3NKVVdkSWNOaVBOU3cyd3gtTUtQalZMS0RSeEMyYjFuSl9JTXNLcyIsInRpZCI6ImE2MjhkYTU4LWIwOTktNDYzZS1iOWJkLTQ5ODdjZDQ1ZWQ3NSIsInVuaXF1ZV9uYW1lIjoibWFsaW5nYS5wdXJuYXNpcmlAYXhpYXRhZGlnaXRhbGxhYnMuY29tIiwidXBuIjoibWFsaW5nYS5wdXJuYXNpcmlAYXhpYXRhZGlnaXRhbGxhYnMuY29tIiwidXRpIjoiRV95NTV0cUhra21SaTAycU5LUVhBQSIsInZlciI6IjEuMCIsInhtc19zdCI6eyJzdWIiOiI1QjJEZzRoN0dKYXdvZVFpMXNDRTBnWDFCR2FOVXhHbjlrUlFkd1duSzRrIn0sInhtc190Y2R0IjoxNDU4ODEyNjczfQ.p9x2gqACPt7nb-ZczX4hAr1EFFvvt76vWN7yBSr3WnEKplTPhB7j9Qg7_v5VLbXxhC3RuQd-KLdtjqpFQKJxc2-uIKVY2q6I_bbSYS7Jfqk14GWqIUq3mzD3fMLtsOrKR7RM4oIVvh1gaaj3P_UEffE-Z32UWJHKSzuppvZWUBDsiMHHAuXbta7im4ADDtsy8I4pfDiHG_-ePXq3eDPbxN_GzwED52CZUgtOIclqzXfJi6w1o_ckLs3tJebp9rBiv8lxlumjUGMGGsxVTMIsunau55N7Qa6xYsmuHh6fkwlIgz7zjXVCLs_9ycrij687PCxxiP55PfX9KvdGPc4rMg");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity <String> entity = new HttpEntity<String>(headers);	    
		String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/users/bd498b64-69f8-4083-85fb-30a519ee8a8c/calendars/AAMkAGM4NTUyNTBiLWY5YjgtNDM0OC1hMTYzLTkxNjIzNTlhYjhjNQBGAAAAAADUpuWe5MUbT61AN2Q3MFK6BwB2bTWNpyDdSbbi-E_vGMXKAAAA3qXOAAA2UevBaRxoT51ch55BVA-lAAAAJMTJAAA=/events", HttpMethod.GET, entity, String.class)
		.getBody();	
		System.out.println("###################################Events##########################");
		System.out.println(body);	
	}
	
	
	//This Api is under beta version and suppose current  AD production version is not supporting for this.
	static void getRooms() {		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "eyJ0eXAiOiJKV1QiLCJub25jZSI6IkFRQUJBQUFBQUFEQ29NcGpKWHJ4VHE5Vkc5dGUtN0ZYUlIzUU1MaFBYc0hyd2ZIcDA4aWdVem54VEFmSkJYd2R5akp5VHU5MlktczZjLWdMT3l5UnNDRk1CcEdoOGUzRGx2VDBCRWZKQnFOTzRXM19IbkNEOGlBQSIsImFsZyI6IlJTMjU2IiwieDV0IjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIiwia2lkIjoiSEJ4bDltQWU2Z3hhdkNrY29PVTJUSHNETmEwIn0.eyJhdWQiOiJodHRwczovL2dyYXBoLm1pY3Jvc29mdC5jb20iLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9hNjI4ZGE1OC1iMDk5LTQ2M2UtYjliZC00OTg3Y2Q0NWVkNzUvIiwiaWF0IjoxNTU4NTAwMTYyLCJuYmYiOjE1NTg1MDAxNjIsImV4cCI6MTU1ODUwNDA2MiwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFWUUFxLzhMQUFBQWFzVzZKa3FFbW05TkVoNktTYTNmMXhBYjdqWXZtVEF6dVNYTktTeTVLditkcnAxcURRdDNseEVtRmVXYmQvd2RXN0hVTVhLTUlFOHB2VWorSitqSkRzaXJLUkVuNkRYMmVJVWJ0OUsrcU44PSIsImFtciI6WyJwd2QiLCJtZmEiXSwiYXBwX2Rpc3BsYXluYW1lIjoiRW1wbG95ZWVBcHBsaWNhdGlvbiIsImFwcGlkIjoiNTYzMDRiNWEtNDdjMC00ZGIwLWJmNDMtZjAzZGUxNzYwOTg5IiwiYXBwaWRhY3IiOiIxIiwiZmFtaWx5X25hbWUiOiJQdXJuYXNpcmkiLCJnaXZlbl9uYW1lIjoiTWFsaW5nYSIsImlwYWRkciI6IjIwMi42OS4yMDAuODIiLCJuYW1lIjoiTWFsaW5nYSBQdXJuYXNpcmkiLCJvaWQiOiJiZDQ5OGI2NC02OWY4LTQwODMtODVmYi0zMGE1MTllZThhOGMiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMTUyNzcyMzI1Mi0xNDYzMjIyMzY2LTE5MjI0NTAyMzMtMTMzMTQzIiwicGxhdGYiOiIzIiwicHVpZCI6IjEwMDMyMDAwNDFBNzBCMDMiLCJzY3AiOiJDYWxlbmRhcnMuUmVhZFdyaXRlIG9wZW5pZCBwcm9maWxlIGVtYWlsIiwic2lnbmluX3N0YXRlIjpbImttc2kiXSwic3ViIjoiblhSc3NKVVdkSWNOaVBOU3cyd3gtTUtQalZMS0RSeEMyYjFuSl9JTXNLcyIsInRpZCI6ImE2MjhkYTU4LWIwOTktNDYzZS1iOWJkLTQ5ODdjZDQ1ZWQ3NSIsInVuaXF1ZV9uYW1lIjoibWFsaW5nYS5wdXJuYXNpcmlAYXhpYXRhZGlnaXRhbGxhYnMuY29tIiwidXBuIjoibWFsaW5nYS5wdXJuYXNpcmlAYXhpYXRhZGlnaXRhbGxhYnMuY29tIiwidXRpIjoiRV95NTV0cUhra21SaTAycU5LUVhBQSIsInZlciI6IjEuMCIsInhtc19zdCI6eyJzdWIiOiI1QjJEZzRoN0dKYXdvZVFpMXNDRTBnWDFCR2FOVXhHbjlrUlFkd1duSzRrIn0sInhtc190Y2R0IjoxNDU4ODEyNjczfQ.p9x2gqACPt7nb-ZczX4hAr1EFFvvt76vWN7yBSr3WnEKplTPhB7j9Qg7_v5VLbXxhC3RuQd-KLdtjqpFQKJxc2-uIKVY2q6I_bbSYS7Jfqk14GWqIUq3mzD3fMLtsOrKR7RM4oIVvh1gaaj3P_UEffE-Z32UWJHKSzuppvZWUBDsiMHHAuXbta7im4ADDtsy8I4pfDiHG_-ePXq3eDPbxN_GzwED52CZUgtOIclqzXfJi6w1o_ckLs3tJebp9rBiv8lxlumjUGMGGsxVTMIsunau55N7Qa6xYsmuHh6fkwlIgz7zjXVCLs_9ycrij687PCxxiP55PfX9KvdGPc4rMg");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity <String> entity = new HttpEntity<String>(headers);	    
		String body = restTemplate.exchange("https://graph.microsoft.com/beta/me/findRooms", HttpMethod.GET, entity, String.class)
		.getBody();	
		System.out.println("###################################Events##########################");
		System.out.println(body);		
	}
	
	//This Api is under beta version and suppose current  AD production version is not supporting for this.
//	static void getUsers() {	
//		RestTemplate restTemplate = new RestTemplate();
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Authorization", ACCESS_TOKEN);
//		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//		HttpEntity <String> entity = new HttpEntity<String>(headers);	    
//		String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/users/bd498b64-69f8-4083-85fb-30a519ee8a8c/people", HttpMethod.GET, entity, String.class)
//		.getBody();	
//		System.out.println("###################################People##########################");
//		System.out.println(body);		
//	}
	
	static void createCalender() {	
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", ACCESS_TOKEN);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		Calender cal = new Calender();
		HttpEntity <Calender> entity = new HttpEntity<Calender>(cal, headers);
		
		//cal.setColor("red");
		cal.setName("TestChin");
		
		Calender result = restTemplate.postForObject("https://graph.microsoft.com/v1.0/users/bd498b64-69f8-4083-85fb-30a519ee8a8c", entity, Calender.class);			    
		System.out.println("###################################People##########################");
		System.out.println(result);		
	}
	
	static void createEvent() {	
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", ACCESS_TOKEN);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		Calender cal = new Calender();
		HttpEntity <Calender> entity = new HttpEntity<Calender>(cal, headers);
		
		//cal.setColor("red");
		cal.setName("TestChin");
		
		Calender result = restTemplate.postForObject("https://graph.microsoft.com/v1.0/me/calendars", entity, Calender.class);			    
		System.out.println("###################################People##########################");
		System.out.println(result);		
	}	

	static void getContacts() {		
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization","Bearer " +  ACCESS_TOKEN);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity <String> entity = new HttpEntity<String>(headers);	    
		String body = restTemplate.exchange("https://outlook.office.com/api/v2.0/me/contacts", HttpMethod.GET, entity, String.class)
		.getBody();	
		System.out.println("###################################Contacts##########################");
		System.out.println(body);		
	}
		
}
