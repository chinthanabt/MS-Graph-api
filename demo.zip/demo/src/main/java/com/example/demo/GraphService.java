package com.example.demo;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class GraphService {
	
	@Autowired
	RestTemplate restTemplate;
	
	
	void getCalenders() {		
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<String>(headers);	    
	    String body = restTemplate.exchange("https://graph.microsoft.com/v1.0/users/bd498b64-69f8-4083-85fb-30a519ee8a8c/calendars", HttpMethod.GET, entity, String.class)
	    .getBody();	    
	    System.out.println("#######################################" + body);		
	}
	
}
